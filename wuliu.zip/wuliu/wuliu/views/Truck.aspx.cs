﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace wuliu.views
{
    public partial class Truck : System.Web.UI.Page
    {
        public void shuaxin()
        {
            DataTable dttk = BLL.BLLlogin.trucksele();
            rptAll.DataSource = dttk;
            rptAll.DataBind();
            
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dtLogin = Session["123"] as DataTable;
                lblName.Text = dtLogin.Rows[0]["UserName"].ToString();

                shuaxin();
            }
        }

        protected void rptAll_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName.ToString()== "Tdel")
            {

                string TruckID = e.CommandArgument.ToString();
               bool bldet= BLL.BLLlogin.Tdel(TruckID);
                if (bldet)
                {
                    this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('删除成功！')</script>");
                    shuaxin();
                }
                else
                {
                    this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('删除失败！')</script>");
                    shuaxin();
                }
            }

            if (e.CommandName.ToString()=="Tupdate")
            {
               string TruckID= e.CommandArgument.ToString();
                Session["TruckID"] = TruckID;
                Response.Redirect("Tupdate.aspx");
            }
        }

        protected void btsel_Click(object sender, EventArgs e)
        {
           string number= tbnumber.Text;
          rptAll.DataSource=  BLL.BLLlogin.likeselect(number);
            rptAll.DataBind();
        }

        protected void tball_Click(object sender, EventArgs e)
        {
            shuaxin(); 
        }

        protected void tbinsert_Click(object sender, EventArgs e)
        {
            Response.Redirect("Tinsert.aspx");
        }
    }
}