﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wuliu.views
{
    public partial class Tinsert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btinsert_Click(object sender, EventArgs e)
        {
            string number= tbnumber.Text;
            string type= tbtype.Text;
           string tonnage= tbtonnage.Text;
           string remark= tbremark.Text;
            string teamname = "";
            if (ddlteamname.SelectedItem.Text=="大众队")
            {
                teamname = "1";
            }
            if (ddlteamname.SelectedItem.Text == "奥迪队")
            {
                teamname = "2";
            }
            if (ddlteamname.SelectedItem.Text == "奔驰队")
            {
                teamname = "3";
            }

          bool blTinsert=  BLL.BLLlogin.Tinsert(teamname,number,type,tonnage,remark);
            if (blTinsert)
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('新增成功！');window.location.href='/views/Truck.aspx';</script>");
            }
            else 
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('新增失败！');window.location.href='/views/Truck.aspx';</script>");
            }
        }
    }
}