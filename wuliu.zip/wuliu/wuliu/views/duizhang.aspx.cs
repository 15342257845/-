﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace wuliu.views
{
    public partial class duizhang : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnselall_Click(object sender, EventArgs e)
        {
            Repeater1.DataSource = BLL.BLLlogin.all();
            Repeater1.DataBind();
        }

        protected void tbsellike_Click(object sender, EventArgs e)
        {
           string bianhao= tblike.Text;
            string fahuoren = tbfahuoren.Text;
            string fahuodanwei = tbfahuodanwei.Text;
            string shouhuoren = tbshouhuoren.Text;
            string shouhuodanwei = tbshouhuodanwei.Text;

           Repeater1.DataSource= BLL.BLLlogin.likeall(bianhao,fahuoren,fahuodanwei,shouhuoren,shouhuodanwei);

            Repeater1.DataBind();
        }
    }
}