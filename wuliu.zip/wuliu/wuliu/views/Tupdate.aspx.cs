﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace wuliu.views
{
    public partial class Tupdate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string TruckID = Session["TruckID"].ToString();

                DataTable dtT = BLL.BLLlogin.Tupdate(TruckID);
                //ddlTeam.DataSource = dtT;
                ////显示的中文名
                //ddlTeam.DataTextField = "TeamName";
                ////teamID
                //ddlTeam.DataValueField = "FK_TeamID";

                ddlTeam.SelectedValue = dtT.Rows[0]["TeamName"].ToString();
                //string teamID= dtT.Rows[0]["FK_TeamID"].ToString();
                //if (teamID=="1")
                //{
                //    ddlTeam.Items.Add("大众队");
                //}
                // else if (teamID == "2")
                //{
                //    ddlTeam.Items.Add("奥迪队");
                //}
                //else if (teamID == "3")
                //{
                //    ddlTeam.Items.Add("奔驰队");
                //}
                string number = dtT.Rows[0]["Number"].ToString();
                string dunwei = dtT.Rows[0]["Tonnage"].ToString();
                string type = dtT.Rows[0]["Type"].ToString();
                string remark = dtT.Rows[0]["Remark"].ToString();
                Label1.Text = dtT.Rows[0]["TruckID"].ToString();

                tbnumber.Text = number;
                tbbuyday.Text = dunwei;
                tbtype.Text = type;
                tbremark.Text = remark;
            }
           
        }

        protected void btupdate_Click(object sender, EventArgs e)
        {
            string TruckID= Label1.Text;
            string TeamID = "";
            // ddlTeam.SelectedValue;//1,2,3
            if (ddlTeam.SelectedValue=="大众队")
            {
                TeamID = "1";
            }
            else if (ddlTeam.SelectedValue=="奥迪队")
            {
                TeamID = "2";
            }

            else if (ddlTeam.SelectedValue == "奔驰队")
            {
                TeamID = "3";
            }
            string number = tbnumber.Text;
            string dunwei = tbbuyday.Text;
            string type = tbtype.Text;
            string remark = tbremark.Text;
            bool blTup= BLL.BLLlogin.Tupdate(number,dunwei,type,remark, TeamID,TruckID);
            if (blTup)
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('修改成功！');window.location.href='/views/Truck.aspx';</script>");
            }
            else
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('修改失败！')</script>");
            }
        }
    }
}