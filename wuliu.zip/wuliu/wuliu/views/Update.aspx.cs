﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace wuliu.views
{
    public partial class Update : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
int userID=Convert.ToInt32(Session["UserID"].ToString());
          DataTable dtus=  BLL.BLLlogin.updatesel(userID);
           tbname.Text= dtus.Rows[0]["UserName"].ToString();
            tbuser.Text = dtus.Rows[0]["Account"].ToString();
            tbpass.Text = dtus.Rows[0]["Password"].ToString();
            tbtel.Text = dtus.Rows[0]["Phone"].ToString();
           int sex= Convert.ToInt32( dtus.Rows[0]["Sex"].ToString());
            int roleID= Convert.ToInt32(dtus.Rows[0]["FK_RoleID"].ToString());

            if (sex==0)
            {
                rbtman.Checked = true;
            }
             else  if (sex == 1)
            {
                rbtwoman.Checked = true;
            }

            if (roleID== 100000001)
            {
                ddljuese.Items.Add("跑车大队队长");
            }
            else if (roleID == 100000002)
            {
                ddljuese.Items.Add("跑车大队副队长");
            }
            else if (roleID == 100000003)
            {
                ddljuese.Items.Add("跑车大队队员");
            }
            }
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           string name= tbname.Text;
            string sex = "";
            if (rbtman.Checked)
            {
                sex = "0";
            }
            else if (rbtwoman.Checked)
            {
                sex = "1";
            }
            string user = tbuser.Text;
            string pass = tbpass.Text;
            string tel = tbtel.Text;
            string roleID = "";
            if (ddljuese.SelectedItem.Value=="跑车大队队长")
            {
                roleID = "10000001";
            }
           else if (ddljuese.SelectedItem.Value == "跑车大队副队长")
            {
                roleID = "10000002";
            }
           else if (ddljuese.SelectedItem.Value == "跑车大队队员")
            {
                roleID = "10000003";
            }
            string userID = Session["UserID"].ToString();
          bool blupdate=  BLL.BLLlogin.update(name,sex,user,pass,tel,roleID,userID);

            if (blupdate)
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('修改成功！');window.location.href='/views/users.aspx';</script>");
            }
            else if (blupdate)
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('修改失败！')</script>");
            }
        }
    }
}