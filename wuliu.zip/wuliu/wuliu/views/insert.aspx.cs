﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace wuliu
{
    public partial class insert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = tbname.Text;
            string sex = "";
            if (rbtman.Checked)
            {
                sex = "0";
            }
            if (rbtwoman.Checked)
            {
                sex = "1";
            }
            string user=  tbUser.Text;
            string pass = tbPass.Text;
            string tel = tbtel.Text;
            string email = tbemali.Text;
            string roleID = "";
            if (ddlroleID.SelectedItem.Value=="跑车大队队长")
            {
                roleID = "10000001";
            }
            else if(ddlroleID.SelectedItem.Value == "跑车大队副队长")
            {
                roleID = "10000002";
            }
            else if(ddlroleID.SelectedItem.Value == "跑车大队队员")
            {
                roleID = "10000003";
            }

            bool  blinsert=  BLL.BLLlogin.insert(name,sex,user,pass,tel,email,roleID);
            if (blinsert)
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('添加成功！');window.location.href='/views/users.aspx';</script>");
            }
            else
            {
                this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('添加失败！')</script>");
            }
        }
    }
}