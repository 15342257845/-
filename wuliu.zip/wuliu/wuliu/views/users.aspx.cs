﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace wuliu
{
    public partial class users : System.Web.UI.Page
    {
        public void shuaxin()
        {
            rptAll.DataSource = BLL.BLLlogin.selectAll();
            rptAll.DataBind();
        }
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dtLogin = Session["123"] as DataTable;
                lblName.Text = dtLogin.Rows[0]["UserName"].ToString();

                if (dtLogin.Rows[0]["RolePurview"].ToString() == "跑车大队队长")
                {
                    shuaxin();
                }
                else
                {
                    rptAll.DataSource = dtLogin;
                    rptAll.DataBind();
                }
                shuaxin();
            }
           
            
        }

        protected void dlAll_ItemCommand(object source, DataListCommandEventArgs e)
        {
        }

        protected void lbtinsert_Click(object sender, EventArgs e)
        {
            Response.Redirect("insert.aspx");
        }

        protected void btselect_Click(object sender, EventArgs e)
        {
            string username = tbUser.Text;
           string email= tbemail.Text;
           string sex = "";
            if (ddllike.SelectedItem.Value=="男")
            {
                sex = "0";
            }
            else if (ddllike.SelectedItem.Value == "女")
            {
                sex = "1";
            }
           rptAll.DataSource= BLL.BLLlogin.likesele(username,email,sex);
            rptAll.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            tbUser.Text = "";
            tbemail.Text = "";
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "DelUser")
            {
                int UserID = Convert.ToInt32(e.CommandArgument.ToString());
                bool blDel = BLL.BLLlogin.DelUser(UserID);
                if (blDel)
                {
                    this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('删除成功！')</script>");
                    shuaxin();
                }

                else
                {
                    this.ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('删除失败！')</script>");
                }
            }


            if (e.CommandName == "Update")
            {
                int UserID = Convert.ToInt32(e.CommandArgument.ToString());
                Session["UserID"] = UserID;
                Response.Redirect("Update.aspx");
                

            }

            
            
            
        }

        protected void lbtinsert_Click1(object sender, EventArgs e)
        {
            Response.Redirect("insert.aspx");
        }
    }
}