﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace wuliu
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lbtLogin_Click(object sender, EventArgs e)
        {
            string user = txtUser.Text;
            string pass = txtPass.Text;
           DataTable dtLogin= BLL.BLLlogin.selectUser(user, pass);
            if (dtLogin.Rows.Count > 0)
            {
                ClientScript.RegisterStartupScript(GetType(), "提示" ,"<script>alert('登录成功');location.href='index.aspx';</script>");
                Session["123"] = dtLogin;
            }
            else
            {
                ClientScript.RegisterStartupScript(GetType(), "提示", "<script>alert('用户名或密码错误！')</script>" );
            }
        }
    }
}