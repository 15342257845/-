﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public  class DALlogin
    {
        public static DataTable selectUser(string User, string pass)
        {
            string sql = @"select RoleID,RolePurview,[UserID],[UserName],[Account], [Password] from [User] t1 inner join Role t2 on t1.FK_RoleID=t2.RoleID where Account='" + User + "' and Password='" + pass + "'";
            DataTable dtselectALL = DBHelper.comSelect(sql);
            return dtselectALL;
        }

        public static DataTable SelALL()
        {
            string sql = @"select RoleID,RolePurview,[UserID],[UserName],[Account], [Password],FK_RoleID from [User] t1,Role t2 where t1.FK_RoleID=t2.RoleID";
            DataTable dtselectALL = DBHelper.comSelect(sql);
            return dtselectALL;
        }

        public static bool DelUser(int UserID)
        {
            string sql = @"delete from [User] where UserID='"+UserID+"'";
            return DAL.DBHelper.insertUpDel(sql);
        }

        public static bool insert(string name,string sex,string account,string password,string phone,string email,string roleID)
        {
            string sql = @"insert into [User](UserName,Sex,Account,Password,Phone,Email,FK_RoleID)
values ('" + name+"',"+sex+","+account+","+password+","+phone+",'"+email+"','"+roleID+"')";
            return DAL.DBHelper.insertUpDel(sql);
        }


        public static DataTable likesel(string username,string email,string sex)
        {
            string sql = @"select RoleID,RolePurview,[UserID],[UserName],[Account], [Password],Email,Sex from [User] t1,Role t2 where t1.FK_RoleID=t2.RoleID and [UserName] like '%"+username+"%' and [Email] like '%"+email+"%' and Sex like '%"+sex+"%'";
            return DBHelper.comSelect(sql);
        }

        public static DataTable updatesel(int userID)
        {
            string sql = @"select UserName,Sex,Account,Password,Phone,FK_RoleID from [User] t1,Role t2 where t1.FK_RoleID=t2.RoleID and [UserID]='" + userID+"'";
            return DBHelper.comSelect(sql);
        }

        public static bool update(string name,string sex,string user,string pass,string tel,string roleID,string userID)
        {
            string sql = @"update [User] set UserName='"+name+"',Sex='"+sex+"',Account='"+user+"',Password='"+pass+"',Phone='"+tel+"',FK_RoleID='"+roleID+"'where UserID="+userID+"";
            return DBHelper.insertUpDel(sql);
        }

        public static DataTable trucksele()
        {
            string sql = @"select TruckID,FK_TeamID,TeamName,Number,Tonnage,Type,t1.Remark from Truck t1,TruckTeam t2 where t1.FK_TeamID=t2.TeamID";
            return DBHelper.comSelect(sql);
        }


        public static  bool Tdel(string TruckID)
        {
            string sql = @"delete from Truck where TruckID='"+TruckID+"'";
            return DAL.DBHelper.insertUpDel(sql);
        }

        public static DataTable Tupdate(string TruckID)
        {
            string sql = @"select TruckID,FK_TeamID,TeamName,Number,Tonnage,Type,t1.Remark from Truck t1,TruckTeam t2 where t1.FK_TeamID=t2.TeamID and TruckID='" + TruckID+"'";
            return DAL.DBHelper.comSelect(sql);
        }

        public static DataTable likeselect(string number)
        {
            string sql = @"select TruckID,FK_TeamID,TeamName,Number,Tonnage,Type,t1.Remark from Truck t1,TruckTeam t2 where t1.FK_TeamID=t2.TeamID and Number like '%"+number+"%' ";
            return DAL.DBHelper.comSelect(sql);
        }

        public static bool Tupdate(string Number, string dunwei, string Type, string Remark, string FK_TeamID, string TruckID)
        {
            string sql = @"update Truck set  Number='"+Number+"',Tonnage='"+dunwei+"',Type='"+Type+"',Remark='"+Remark+"',FK_TeamID='"+FK_TeamID+"' where  TruckID='"+TruckID+"'";
            return DAL.DBHelper.insertUpDel(sql);
        }

        public static bool Tinsert(string FK_TeamID,string Number, string Type,string Tonnage,string Remark)
        {
            string sql = @"insert into Truck(FK_TeamID,Number,Type,Tonnage,t1.Remark)
values(" + FK_TeamID + ",'" + Number + "','" + Type + "'," + Tonnage + ",'" + Remark + "')";
            return DAL.DBHelper.insertUpDel(sql);
        }

        public static DataTable kefusel(string ID)
        {
            string sql = @"select CarriersID,SendAddress,SendLinkman,SendPhone,FK_ReceiveAddress,ReceiveLinkman,ReceivePhone,ReceiveDate from Carriers where CarriersID='" + ID+"'";
            return DAL.DBHelper.comSelect(sql);
        }

        public static DataTable all()
        {
            string sql = @"select CarriersID, SendAddress,SendLinkman,SendPhone,FK_ReceiveAddress,ReceiveLinkman,ReceivePhone,ReceiveDate from Carriers";
            return DAL.DBHelper.comSelect(sql);
        }

        public static DataTable likeall(string ID, string SendLinkman, string SendAddress, string ReceiveLinkman, string FK_ReceiveAddress)
        {
            string sql = @"select CarriersID, SendAddress,SendLinkman,SendPhone,FK_ReceiveAddress,ReceiveLinkman,ReceivePhone,ReceiveDate from Carriers where CarriersID like'%"+ID+ "%' and SendLinkman like'%" + SendLinkman + "%' and SendAddress like'%" + SendAddress + "%'and ReceiveLinkman like'%" + ReceiveLinkman + "%' and FK_ReceiveAddress like'%" + FK_ReceiveAddress + "%'";
            return DAL.DBHelper.comSelect(sql);
        }

    }
}
