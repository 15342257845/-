﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public class BLLlogin
    {
        public static DataTable selectUser(string User, string pass)
        {
            return DAL.DALlogin.selectUser(User, pass);
        }

        public static DataTable selectAll()
        {
            return DAL.DALlogin.SelALL();
        }

        public static bool DelUser(int userID)
        {
            return DAL.DALlogin.DelUser(userID);
        }

        public static bool insert(string name, string sex, string account, string password, string phone, string email,string roleID)
        {
            return DAL.DALlogin.insert(name,sex,account,password,phone,email,roleID);

        }

        public static DataTable likesele(string username, string email, string sex)
        {
            return DAL.DALlogin.likesel(username,email,sex);
        }
        public static DataTable updatesel(int userID)
        {
            return DAL.DALlogin.updatesel(userID);
        }

        public static bool update(string name,string sex, string user, string pass, string tel, string roleID, string userID)
        {
            return DAL.DALlogin.update(name,sex, user, pass, tel, roleID, userID);
        }

        public static DataTable trucksele()
        {
            return DAL.DALlogin.trucksele();
        }

        public static bool Tdel(string TruckID)
        {
            return DAL.DALlogin.Tdel(TruckID);
        }

        public static DataTable Tupdate(string TruckID)
        {
            return DAL.DALlogin.Tupdate(TruckID);
        }

        public static DataTable likeselect(string number)
        {
            return DAL.DALlogin.likeselect(number);
        }

        public static bool Tupdate(string Number, string dunwei, string Type, string Remark, string FK_TeamID, string TruckID)
        {
            return DAL.DALlogin.Tupdate(Number,dunwei,Type,Remark,FK_TeamID,TruckID);
        }
        public static bool Tinsert(string FK_TeamID, string Number, string Type, string Tonnage, string Remark)
        {
            return DAL.DALlogin.Tinsert(FK_TeamID,Number,Type,Tonnage,Remark);
        }

        public static DataTable kefusel(string ID)
        {
            return DAL.DALlogin.kefusel(ID);
        }

        public static DataTable all()
        {
            return DAL.DALlogin.all();
        }

        public static DataTable likeall(string ID, string SendLinkman, string SendAddress, string ReceiveLinkman, string FK_ReceiveAddress)
        {
            return DAL.DALlogin.likeall(ID, SendLinkman, SendAddress, ReceiveLinkman ,FK_ReceiveAddress);
        }

    }
}
